import json
import random
disallowed = []
wrong_spot = {}
correct = {}
previous_word = ""
potential_words = []
attempted_words = []
results = []
steps = 0


with open('wordles.json') as f:
    wordles = json.load(f)

all_words = sorted(wordles)
potential_words = all_words

starting_word = all_words[random.randint(0,len(all_words) - 1)]
print("starting word is ", starting_word)
previous_word = starting_word

def step(potential_words, previous_word):
    global disallowed, wrong_spot, correct, attempted_words, steps

    result = input("input result (green: g, yellow: y, grey: r): ").strip().lower()
    results.append(result)

    # Update knowledge
    for i, r in enumerate(result):
        letter = previous_word[i]
        if r == "g":
            correct[letter] = i
        elif r == "y":
            wrong_spot[letter] = i
        elif r == "r":
            # Only disallow if it's not already confirmed somewhere else
            if letter not in correct and letter not in wrong_spot:
                disallowed.append(letter)
        if letter in correct or letter in wrong_spot:
            if letter in disallowed:
                disallowed.remove(letter)

    disallowed = list(set(disallowed))  # deduplicate

    print("green:", correct)
    print("yellow:", wrong_spot)
    print("grey:", disallowed)

    # Filter potential words
    filtered = []
    for word in potential_words:
        # Skip any word with a disallowed letter
        if any(letter in disallowed for letter in word):
            continue

        # Must have all greens in correct spots
        if any(word[idx] != ch for ch, idx in correct.items()):
            continue

        # Must have yellows in word but NOT in the same spot
        if any(ch not in word or word[idx] == ch for ch, idx in wrong_spot.items()):
            continue

        filtered.append(word)

    potential_words = filtered
    attempted_words.append(previous_word)
    print("potential words: ", potential_words)

    if result != "ggggg":
        nextword = findNextWord(potential_words)
        print("Next word suggestion:", nextword)
        step(potential_words, nextword)
    else:
        print("Answer found!")
        print("steps:")
        for i in results:
            squares = ""
            steps = steps + 1
            for j in i:
                if j == "g":
                    squares = squares + "🟩" + " "
                if j == "y":
                    squares = squares + "🟨" + " "
                if j == "r":
                    squares = squares + "⬜" + " "
            print(squares)
        print("found in ", steps, "steps")



def findNextWord(potential_words):
    global attempted_words
    nextword = random.choice(potential_words)
    if nextword in attempted_words:
        return findNextWord(potential_words)
    return nextword


step(potential_words, starting_word)